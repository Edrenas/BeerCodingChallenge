<!DOCTYPE html>
<!-- Template by Quackit.com -->
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">

  
</head>
	<body>

		<div class="jumbotron feature">
			<div class="container">
				<h1><span class="glyphicon glyphicon-equalizer"></span> Spruce Beer</h1>
				<?php include('BeerInfo.php'); ?> 
			</div>
		</div>

		<!-- Content -->
		<div class="container">

			<!-- Heading -->
			<div class="row">
				<div class="col-lg-12">
					<h1 class="page-header">
						Beer Ratings 
					</h1>
				 </div>
			</div>
		  
		<?php include('BeerReviews.php'); ?> 
			
		</div>
		<!-- /.container -->
		
		
		<!-- jQuery -->
		<script src="js/jquery-1.11.3.min.js"></script>

		<!-- Bootstrap Core JavaScript -->
		<script src="js/bootstrap.min.js"></script>
		
		<!-- IE10 viewport bug workaround -->
		<script src="js/ie10-viewport-bug-workaround.js"></script>
		
		<!-- Placeholder Images -->
		<script src="js/holder.min.js"></script>
	</body>
</html>
