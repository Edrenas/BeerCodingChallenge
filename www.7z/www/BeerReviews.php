<!-- Get beer info -->
<?php
$json = file_get_contents('https://api.untappd.com/v4/beer/info/110569/?client_id=3B699F2A6042F01F5F198865B533DAE74E4498EF&client_secret=6A750CCE8AC023F996133E376E3B58EC5478BCD5&fbclid=IwAR0fWe1OrwOF83CsQa1C7pJ7pXDsa3u_gaZUBHltLwsts907ckVx8JiiGfY&bid=110569');
$beerInfo = json_decode($json);
?>

<!-- Formats beer review details. -->
<?php
	foreach($beerInfo->response->beer->checkins->items as $rating) {

	$htmlOut = "<div class='col-md-12'>
			   Rating: " . $rating->rating_score . "</div>";

	$htmlOut .= "<div class='col-md-12'>
			   Name: " . $rating->user->first_name . " " . $rating->user->last_name . "</div>";
			   
	$htmlOut .= "<div class='col-md-12'>
			   Date: " . $rating->created_at . "</div>";
			   
	echo $htmlOut;
	echo "_______________________________";
	}
?>