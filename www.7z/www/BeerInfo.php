<!-- Get beer info -->
<?php
$json = file_get_contents('https://api.untappd.com/v4/beer/info/110569/?client_id=3B699F2A6042F01F5F198865B533DAE74E4498EF&client_secret=6A750CCE8AC023F996133E376E3B58EC5478BCD5&fbclid=IwAR0fWe1OrwOF83CsQa1C7pJ7pXDsa3u_gaZUBHltLwsts907ckVx8JiiGfY&bid=110569');
$beerInfo = json_decode($json);
?>   

	<div class="col-md-12">
     Brewery: <?php echo $beerInfo->response->beer->brewery->brewery_name; ?>
    </div>
	
	    <div class="col-md-12">
      Name: <?php echo $beerInfo->response->beer->beer_name; ?>
    </div>
	
	    <div class="col-md-12">
      Style: <?php echo $beerInfo->response->beer->beer_style; ?>
    </div>
	
	    <div class="col-md-12">
      ABV: <?php echo $beerInfo->response->beer->beer_abv; ?>
    </div>  
	
	<div class="col-md-12">
     IBU: <?php echo $beerInfo->response->beer->beer_ibu; ?>
    </div>  
	
	<div class="col-md-12">
     Rating: <?php echo $beerInfo->response->beer->rating_score; ?>
    </div>	
	<br />
	
	<div class="col-md-12">
     Label:
	 <br />
	 <img src="pics/Spruce_Beer.png">
    </div>
	<br />
	
	<div class="col-md-12">
     Brewery Label:
	<br />
	<img src="pics/Garrison_Logo.png" width="200px;" height="100px;">
    </div>